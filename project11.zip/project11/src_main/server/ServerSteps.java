package com.pelatro.projectAutomation.server;

import com.pelatro.projectAutomation.utils.ConnectRemoteServer;
import java.io.File;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class ServerSteps {

    @Given("I create a directory \"(.*)\" in my home directory")
    public void createDirectory(String dirName) {
        String response = new ConnectRemoteServer().execute("mkdir /home/pelatro/" + dirName);

        if (response.equals("mkdir: cannot create directory ‘/home/pelatro/" + dirName + "’: File exists")) {
            new ConnectRemoteServer().execute("rm -rf /home/pelatro/" + dirName);
            new ConnectRemoteServer().execute("mkdir /home/pelatro/" + dirName);
            System.out.println("Directory existed, so it was deleted and created again.");
        }

        String ls = new ConnectRemoteServer().execute("ls /home/pelatro/");
        if (!ls.contains(dirName)) {
            throw new AssertionError("Directory creation failed for: " + dirName);
        }
    }

    @Given("I create the file \"(.*)\" in the directory \"(.*)\"")
    public void createFiles(String fileName, String dirName) {
        // Create the file inside the specified directory
        new ConnectRemoteServer().execute("touch /home/pelatro/" + dirName + "/" + fileName);

        for (int i = 1; i <= 10; i++) {
            new ConnectRemoteServer().execute("echo 'line " + i + "' >> /home/pelatro/" + dirName + "/" + fileName);
            String lsFile = new ConnectRemoteServer().execute("ls /home/pelatro/" + dirName + "/" + fileName);
            if (lsFile.isEmpty()) {
                throw new AssertionError("Failed to write data to " + fileName);
            }
        }

        String ls = new ConnectRemoteServer().execute("ls /home/pelatro/" + dirName);
        if (!ls.contains(fileName)) {
            throw new AssertionError("File creation failed for: " + fileName);
        }
    }

    @Given("I list all the files in the directory \"(.*)\"")
    public void listAllFiles(String dirName) {
        String ls = new ConnectRemoteServer().execute("ls /home/pelatro/" + dirName);
        System.out.println("Files in directory " + dirName + ": " + ls);
    }

    @Given("I put the contents of all files in the directory \"(.*)\" into a new file \"(.*)\"")
    public void catAllFilesContentToNewFile(String dirName, String destDirName) {
        new ConnectRemoteServer().execute("mkdir -p /home/pelatro/" + destDirName);

        new ConnectRemoteServer().execute("cat /home/pelatro/" + dirName + "/* >> /home/pelatro/" + destDirName + "/allContent");

        String cat = new ConnectRemoteServer().execute("cat /home/pelatro/" + destDirName + "/allContent");
        if (cat.isEmpty()) {
            throw new AssertionError("Failed to copy all file contents into the new file.");
        }
    }

    @And("I download the new file to my local machine and display its content")
    public void downloadNewFile() {
        String downloadedFile = new ConnectRemoteServer().download("/home/pelatro", "/home/pelatro/copyContent/allContent");

        String ls = new ConnectRemoteServer().execute("ls /home/pelatro");
        String fileName = new File(downloadedFile).getName();
        if (!ls.contains(fileName)) {
            throw new AssertionError("File download failed for: " + fileName);
        }

        System.out.println("Downloaded file: " + downloadedFile);

        String cat = new ConnectRemoteServer().execute("cat " + downloadedFile);
        System.out.println("Content of the downloaded file: " + cat);
    }

    @Then("I verify that the directory \"(.*)\" exists in my home directory")
    public void verifyDirectoryExists(String dirName) {
        String ls = new ConnectRemoteServer().execute("ls /home/pelatro/");
        if (!ls.contains(dirName)) {
            throw new AssertionError("Directory " + dirName + " was not found in the home directory.");
        }
    }

    @Then("I verify that the file \"(.*)\" exists in the directory \"(.*)\"")
    public void verifyFileExists(String fileName, String dirName) {
        String ls = new ConnectRemoteServer().execute("ls /home/pelatro/" + dirName);
        if (!ls.contains(fileName)) {
            throw new AssertionError("File " + fileName + " was not found in directory " + dirName);
        }
    }

    @Then("I verify that all files in directory \"(.*)\" were concatenated into the new file \"(.*)\"")
    public void verifyFilesConcatenated(String dirName, String destDirName) {
        String cat = new ConnectRemoteServer().execute("cat /home/pelatro/" + destDirName + "/allContent");
        if (cat.isEmpty()) {
            throw new AssertionError("The concatenated content is empty or not copied correctly into " + destDirName + "/allContent.");
        }
    }
}
