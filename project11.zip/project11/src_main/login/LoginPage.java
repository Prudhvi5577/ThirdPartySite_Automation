package com.pelatro.projectAutomation.login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pelatro.projectAutomation.generic.Page;

import net.thucydides.core.webdriver.WebdriverAssertionError;

public class LoginPage extends Page {

	WebDriver driver;
	public LoginPage(WebDriver driver) {
		
		super(driver);
		this.driver = driver;
	}
	

	
    // Method to enter username and password
    public void enterUserNamePassword(String userName, String password) {
        String userNameXpath = "//input[@id='username']";
        String passwordXpath = "//input[@id='password']";

        type(userNameXpath, userName);  // Type username into the username field
        type(passwordXpath, password);  // Type password into the password field
    }

    
    
    // Method to click the submit button
    public void clickSubmit() {
        String submitXpath = "//button[@id='submit']";
        click(submitXpath);  // Click the submit button
    }

    
    
    // Method to validate login by checking the new URL and the expected text
    public boolean validateLogin(String newUrl, String expectedText) {
        String currentUrl = driver.getCurrentUrl();  // Get current URL of the page

        if (!newUrl.equals(currentUrl)) {  // Check if the current URL matches the expected URL
            return false;
        }

        if (!driver.getPageSource().contains(expectedText)) {  // Check if the page contains the expected text
            return false;
        }

        if (!isLogoutButtonVisible()) {  // Check if logout button is visible
            return false;
        }

        return true;
    }

    // Method to check if the logout button is visible
    public boolean isLogoutButtonVisible() {
        WebElement logoutButton = driver.findElement(By.xpath("//a[normalize-space()='Log out']"));
        return logoutButton.isDisplayed();  // Return true if the logout button is visible
    }



	public boolean isErrorMessageDisplayed() {
		 WebElement errorMessage = driver.findElement(By.xpath("//div[@class='error-message']"));
	        return errorMessage.isDisplayed();
		
	}



	public Object verifyErrorMessageText() {
		WebElement errorMessage = driver.findElement(By.xpath("//div[@class='error-message']"));
        return errorMessage.getText();
	}
    
    



}

//	public void enterUserNamePasswordAndPressSubmit(String userName, String password) {
//
//		String userNameXpath = "//input[@id='username']";
//		String passwordXpath = "//input[@id='password']";
//		String submitXpath = "//button[@id='submit']";
//
//		type(userNameXpath, userName);
//		type(passwordXpath, password);
//		click(submitXpath);
//	}
//
//	public boolean validateLogin(String destUrl, String text) {
//		String currentURL = getCurrentURL();
//
//		if (destUrl.equals(currentURL)) {
//			System.out.println("Reached home page");
//		} else {
//			return false;
//		}
//
//		if (pageContains(text)) {
//			System.out.println("Text visible on Home page");
//		} else {
//			return false;
//		}
//
//		if (element(By.xpath("//a[normalize-space()='Log out']")).waitUntilVisible().isVisible()) {
//			System.out.println("Logout button visible");
//		} else {
//			return false;
//		}
//		return true;
//
//	}
//
//	public boolean validateErrMsg(String errText) {
//
//		if (pageContains(errText)) {
//			System.out.println("Username Error message is visible");
//		} else {
//			return false;
//		}
//
//		return true;
//
//	}
//
//	public boolean validatePasswdErrMsg(String passwdErrText) {
//		if (pageContains(passwdErrText)) {
//			System.out.println("Password Error message is visible");
//		} else {
//
//			return false;
//
//		}
//
//		return false;
//
//	}
//}
