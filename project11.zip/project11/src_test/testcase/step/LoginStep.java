package com.pelatro.projectAutomation.testcase.step;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.pelatro.projectAutomation.login.LoginPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class LoginStep {

	private LoginPage loginPage;

	// Step to open the app using the provided URL
	@Given("I opened the app using following (.*)")
	public void openApp(String url) {
		loginPage.openAt(url);
	}

	// Step to enter username and password
	@And("I enter (.*) and (.*)")
	public void enterUsernameAndPassword(String userName, String password) {
		loginPage.enterUserNamePassword(userName, password);
	}

	// Step to click on the submit button
	@And("clicked on submit")
	public void clickSubmit() {
		loginPage.clickSubmit();
	}

	// Step to validate if login was successful, by checking the new URL and
	// expected text
	@Then("validate login with (.*) and (.*)")
	public void validateLogin(String newUrl, String expectedText) {
		boolean loginSuccess = loginPage.validateLogin(newUrl, expectedText);
		assertTrue("Login validation failed!", loginSuccess);
	}

	// Step to validate if the logout button is visible
	@And("logout button")
    public void validateLogoutButton() {
        assertTrue("Logout button is not visible!", loginPage.isLogoutButtonVisible());
	}

	@Then("I should see an error message")
	public void verifyErrorMessage() {
		assertTrue("Error message should be displayed", loginPage.isErrorMessageDisplayed());
	}

	@And("the error message text should be (.*)")
	public void verifyErrorMessageText(String expectedErrorText) {
		assertEquals("Error message text does not match", expectedErrorText, loginPage.verifyErrorMessageText());
	}
}

//	@Given("I opened the app using following (.*)")
//	public void openApp(String url) {
//		loginPage.openAt(url);	
//	}
//	
//	@And("I enter (.*) and (.*) and press submit")
//	public void enterUsernameAndPassword(String userName, String password) {
//		loginPage.enterUserNamePasswordAndPressSubmit(userName, password);
//	}
//	
//	@Then("validate login with (.*) and (.*) and logout button")
//	public void userReachesHomePage(String destUrl, String text) {
//		if (!loginPage.validateLogin(destUrl,text))
//			throw new AssertionError("Login Failed !!!");
//	}
// 

//}
